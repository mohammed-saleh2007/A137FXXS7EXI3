
#pragma once

#include_next <sys/types.h>

#include <linux/types.h>

typedef unsigned short __uid_t;
typedef unsigned short __gid_t;
